package com.attendance;

import android.app.Application;

import com.androidnetworking.AndroidNetworking;
import com.attendance.misc.utils.Extras;


public class Attendance extends Application {

    private static Attendance istance;
    private Extras pref;

    /**
     * Instance of this class
     *
     * @return
     */
    public static Attendance getInstance() {
        return istance;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        istance = this;
        AndroidNetworking.initialize(this);
        pref = new Extras(this);
        pref.setrollNo(80);
    }

}


package com.attendance.data.network;

import com.google.android.material.textfield.TextInputEditText;


public interface inputview {

    TextInputEditText gettext();

}

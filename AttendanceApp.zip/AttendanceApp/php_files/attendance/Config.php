<?php

//constant database config variable

define("HOST", "localhost");
define("USERNAME", "root");
define("PASS", "");
define("DBNAME", "demo2");

?>
